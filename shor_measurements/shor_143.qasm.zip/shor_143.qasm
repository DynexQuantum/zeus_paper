OPENQASM 3.0;
include "qelib1.inc";
gate gg a,b,c,d{
ccx d,a,b;ccx d,a,c;}
gate gh a,b,c{
ccx c,a,b;}
gate gi a,b,c,d,e,f,g,h{
x b;ccx h,a,g;gg b,d,e,g;ccx h,a,g;x b;ccx h,a,g;gh b,c,g;ccx h,a,g;x a;ccx h,a,g;gg b,e,f,g;ccx h,a,g;x a;}
gate ga a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
cx j,a;cx j,r;ccx r,a,j;cx k,b;cx k,j;ccx j,b,k;cx l,c;cx l,k;ccx k,c,l;cx m,d;cx m,l;ccx l,d,m;cx n,e;cx n,m;ccx m,e,n;cx o,f;cx o,n;ccx n,f,o;cx p,g;cx p,o;ccx o,g,p;cx q,h;cx q,p;ccx p,h,q;cx q,i;ccx p,h,q;cx q,p;cx p,h;ccx o,g,p;cx p,o;cx o,g;ccx n,f,o;cx o,n;cx n,f;ccx m,e,n;cx n,m;cx m,e;ccx l,d,m;cx m,l;cx l,d;ccx k,c,l;cx l,k;cx k,c;ccx j,b,k;cx k,j;cx j,b;ccx r,a,j;cx j,r;cx r,a;}
gate gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gi a,b,l,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gi a,b,l,p,q,r,t,u;}
gate gc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x j;x k;x l;x m;x q;ga a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;x q;x m;x l;x k;x j;}
gate gd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
cx s,j;cx s,k;cx s,l;cx s,m;cx s,q;ga a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;cx s,q;cx s,m;cx s,l;cx s,k;cx s,j;}
gate gf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
inv @ gc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;cx i,s;gd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s;}
gate gl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gm a,b,c,d,e{
ccx e,a,b;ccx e,a,c;ccx e,a,d;}
gate gn a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,c,f,g,i;ccx j,a,i;x b;ccx j,a,i;gh b,e,i;ccx j,a,i;x a;ccx j,a,i;gm b,d,g,h,i;ccx j,a,i;x a;}
gate go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gn a,b,l,m,n,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gn a,b,l,m,n,p,q,r,t,u;}
gate gq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gr a,b,c,d,e,f{
ccx f,a,b;ccx f,a,c;ccx f,a,d;ccx f,a,e;}
gate gs a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gr b,c,e,g,h,j;ccx k,a,j;x b;ccx k,a,j;gh b,g,j;ccx k,a,j;x a;ccx k,a,j;gr b,d,f,h,i,j;ccx k,a,j;x a;}
gate gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gs a,b,l,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gs a,b,l,m,n,o,p,q,r,t,u;}
gate gv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gw a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,c,e,g,i;ccx j,a,i;x b;ccx j,a,i;gh b,g,i;ccx j,a,i;x a;ccx j,a,i;gm b,d,f,h,i;ccx j,a,i;x a;}
gate gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gw a,b,l,m,n,o,r,s,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gw a,b,l,m,n,o,r,s,t,u;}
gate gz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gE a,b,c,d,e,f,g,h{
x b;ccx h,a,g;gg b,c,d,g;ccx h,a,g;x b;ccx h,a,g;gg b,c,f,g;ccx h,a,g;x a;ccx h,a,g;gg b,d,e,g;ccx h,a,g;x a;}
gate gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gE a,b,n,o,p,q,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gE a,b,n,o,p,q,t,u;}
gate gH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gE a,b,l,m,n,o,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gE a,b,l,m,n,o,t,u;}
gate gL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gl a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gq c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gv e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gz g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gq g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gl e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gH c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gL a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gO a,b,c,d,e,f,g,h{
ccx h,a,b;ccx h,a,c;ccx h,a,d;ccx h,a,e;ccx h,a,f;ccx h,a,g;}
gate gP a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,c,e,g,i;ccx j,a,i;x b;ccx j,a,i;gO b,c,d,e,f,g,h,i;ccx j,a,i;x a;ccx j,a,i;gm b,d,f,h,i;ccx j,a,i;x a;}
gate gQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gP a,b,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gP a,b,m,n,o,p,q,r,t,u;}
gate gS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gT a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,c,e,f,i;ccx j,a,i;x b;ccx j,a,i;gr b,c,d,e,h,i;ccx j,a,i;x a;ccx j,a,i;gm b,d,f,g,i;ccx j,a,i;x a;}
gate gU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gT a,b,l,m,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gT a,b,l,m,o,p,q,r,t,u;}
gate gW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gX a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gm b,e,h,i,j;ccx k,a,j;x b;ccx k,a,j;gm b,d,e,f,j;ccx k,a,j;x a;ccx k,a,j;gr b,c,f,g,h,j;ccx k,a,j;x a;}
gate gY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gX a,b,l,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gX a,b,l,m,n,o,p,q,r,t,u;}
gate gba a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbb a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gr b,d,g,h,i,j;ccx k,a,j;x b;ccx k,a,j;gm b,f,g,h,j;ccx k,a,j;x a;ccx k,a,j;gr b,c,e,g,i,j;ccx k,a,j;x a;}
gate gbc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbb a,b,l,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbb a,b,l,m,n,o,p,q,r,t,u;}
gate gbe a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbf a,b,c,d,e,f,g,h,i{
x b;ccx i,a,h;gm b,d,e,f,h;ccx i,a,h;x b;ccx i,a,h;gm b,c,d,e,h;ccx i,a,h;x a;ccx i,a,h;gm b,e,f,g,h;ccx i,a,h;x a;}
gate gbg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbf a,b,l,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbf a,b,l,o,p,q,r,t,u;}
gate gbi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbk a,b,c,d,e,f,g,h,i{
x b;ccx i,a,h;gm b,c,d,e,h;ccx i,a,h;x b;ccx i,a,h;gm b,c,e,g,h;ccx i,a,h;x a;ccx i,a,h;gm b,d,e,f,h;ccx i,a,h;x a;}
gate gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbk a,b,m,n,o,p,q,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbk a,b,m,n,o,p,q,t,u;}
gate gbn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbp a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gr b,c,d,f,h,i;ccx j,a,i;x b;ccx j,a,i;gm b,d,g,h,i;ccx j,a,i;x a;ccx j,a,i;gm b,c,d,e,i;ccx j,a,i;x a;}
gate gbq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbp a,b,l,m,n,o,p,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbp a,b,l,m,n,o,p,r,t,u;}
gate gbs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbu a,b,c,d,e,f,g{
ccx g,a,b;ccx g,a,c;ccx g,a,d;ccx g,a,e;ccx g,a,f;}
gate gbv a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gO b,d,e,f,g,h,i,j;ccx k,a,j;x b;ccx k,a,j;gr b,e,f,g,i,j;ccx k,a,j;x a;ccx k,a,j;gbu b,c,e,f,h,i,j;ccx k,a,j;x a;}
gate gbw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbv a,b,l,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbv a,b,l,m,n,o,p,q,r,t,u;}
gate gby a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gS a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gW c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gba e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbe g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gbi g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbn e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbs c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gby a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gbB a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gr b,c,f,g,h,i;ccx j,a,i;x b;ccx j,a,i;gr b,c,e,f,g,i;ccx j,a,i;x a;ccx j,a,i;gr b,c,d,f,h,i;ccx j,a,i;x a;}
gate gbC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbB a,b,l,m,n,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbB a,b,l,m,n,p,q,r,t,u;}
gate gbE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbF a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gr b,c,d,e,g,j;ccx k,a,j;x b;ccx k,a,j;gm b,c,e,i,j;ccx k,a,j;x a;ccx k,a,j;gr b,d,e,f,h,j;ccx k,a,j;x a;}
gate gbG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbF a,b,l,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbF a,b,l,m,n,o,p,q,r,t,u;}
gate gbI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbJ a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gr b,d,e,f,h,j;ccx k,a,j;x b;ccx k,a,j;gm b,c,d,i,j;ccx k,a,j;x a;ccx k,a,j;gm b,c,e,g,j;ccx k,a,j;x a;}
gate gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbJ a,b,l,n,o,p,q,r,s,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbJ a,b,l,n,o,p,q,r,s,t,u;}
gate gbM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbN a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,d,f,h,i;ccx j,a,i;x b;ccx j,a,i;gbu b,c,d,e,g,h,i;ccx j,a,i;x a;ccx j,a,i;gm b,c,e,f,i;ccx j,a,i;x a;}
gate gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbN a,b,l,m,n,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbN a,b,l,m,n,p,q,r,t,u;}
gate gbQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbR a,b,c,d,e,f,g,h{
x b;ccx h,a,g;gg b,c,e,g;ccx h,a,g;x b;ccx h,a,g;gr b,c,d,e,f,g;ccx h,a,g;x a;ccx h,a,g;gg b,d,f,g;ccx h,a,g;x a;}
gate gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbR a,b,n,o,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbR a,b,n,o,q,r,t,u;}
gate gbU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gbW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbR a,b,l,m,o,p,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbR a,b,l,m,o,p,t,u;}
gate gbY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gbW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gbW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gbW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gca a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,c,d,g,i;ccx j,a,i;x b;ccx j,a,i;gr b,c,f,g,h,i;ccx j,a,i;x a;ccx j,a,i;gm b,d,e,h,i;ccx j,a,i;x a;}
gate gcb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gca a,b,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gca a,b,m,n,o,p,q,r,t,u;}
gate gcd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcf a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gm b,c,f,h,i;ccx j,a,i;x b;ccx j,a,i;gm b,e,g,h,i;ccx j,a,i;x a;ccx j,a,i;gm b,c,d,f,i;ccx j,a,i;x a;}
gate gcg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcf a,b,l,m,n,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcf a,b,l,m,n,p,q,r,t,u;}
gate gci a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gck a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gbE a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbI c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbM e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbQ g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gbU g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbY e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcd c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gci a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gcl a,b,c,d,e,f{
x b;ccx f,a,e;gh b,c,e;ccx f,a,e;x b;ccx f,a,e;gg b,c,d,e;ccx f,a,e;x a;ccx f,a,e;gh b,d,e;ccx f,a,e;x a;}
gate gcm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcl a,b,p,q,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcl a,b,p,q,t,u;}
gate gco a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcp a,b,c,d,e,f,g,h,i{
x b;ccx i,a,h;gh b,f,h;ccx i,a,h;x b;ccx i,a,h;gm b,c,d,e,h;ccx i,a,h;x a;ccx i,a,h;gh b,g,h;ccx i,a,h;x a;}
gate gcq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcp a,b,l,p,q,r,s,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcp a,b,l,p,q,r,s,t,u;}
gate gcs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gct a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcl a,b,n,o,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcl a,b,n,o,t,u;}
gate gcv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gct a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gct a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gct a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcl a,b,l,m,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcl a,b,l,m,t,u;}
gate gcz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gco a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcs c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbE e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbI g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gcv g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcz e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbU c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbY a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gcD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gcv a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gco c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcs e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbE g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gco g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcv e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcz c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbU a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcl a,b,m,n,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcl a,b,m,n,t,u;}
gate gcG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcl a,b,o,p,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcl a,b,o,p,t,u;}
gate gcJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcl a,b,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcl a,b,q,r,t,u;}
gate gcM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcN a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gh b,h,i;ccx j,a,i;x b;ccx j,a,i;gm b,d,f,g,i;ccx j,a,i;x a;ccx j,a,i;gr b,c,e,f,g,i;ccx j,a,i;x a;}
gate gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcN a,b,l,m,p,q,r,s,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcN a,b,l,m,p,q,r,s,t,u;}
gate gcQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcU a,b,c,d,e,f,g{
x b;ccx g,a,f;gg b,d,e,f;ccx g,a,f;x b;ccx g,a,f;gm b,c,d,e,f;ccx g,a,f;x a;ccx g,a,f;gh b,c,f;ccx g,a,f;x a;}
gate gcV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gcU a,b,l,o,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gcU a,b,l,o,r,t,u;}
gate gcX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gcV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gcV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gcV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gcZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gcG a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcJ c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcM e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcQ g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gcM g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcJ e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcG c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcX a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gde a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gbn a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbi c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gci e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcd g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gW g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gS e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbQ c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbM a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gdi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gcd a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbY c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gbU e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcz g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gbM g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbI e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gbE c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcs a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
gate gdj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gbR a,b,m,n,p,q,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gbR a,b,m,n,p,q,t,u;}
gate gdl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gdj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gdj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gdj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gdm a,b,c,d,e,f,g,h,i,j,k{
x b;ccx k,a,j;gr b,c,d,g,i,j;ccx k,a,j;x b;ccx k,a,j;gr b,d,f,h,i,j;ccx k,a,j;x a;ccx k,a,j;gr b,c,d,e,g,j;ccx k,a,j;x a;}
gate gdn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u{
gdm a,b,l,m,n,o,p,q,r,t,u;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;gdm a,b,l,m,n,o,p,q,r,t,u;}
gate gdp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v{
gdn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;inv @ gdn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;x k;cx k,u;x k;gdn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v;}
gate gds a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B{
gdl a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcX c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcG e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;gcJ g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;cx i,a;ccx B,a,i;cx i,a;cx j,b;ccx B,b,j;cx j,b;cx k,c;ccx B,c,k;cx k,c;cx l,d;ccx B,d,l;cx l,d;cx m,e;ccx B,e,m;cx m,e;cx n,f;ccx B,f,n;cx n,f;cx o,g;ccx B,g,o;cx o,g;cx p,h;ccx B,h,p;cx p,h;inv @ gdp g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcQ e,f,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcM c,d,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;inv @ gcJ a,b,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B;}
qreg q[28];
creg j0[1];
creg j1[1];
creg j2[1];
creg j3[1];
creg j4[1];
creg j5[1];
creg k0[1];
creg k1[1];
creg k2[1];
x q[0];
h q[27];
gN q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
h q[27];
measure q[27] -> j0[0];
if(j0==1) x q[27];
h q[27];
gbA q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(j0==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> j1[0];
if(j1==1) x q[27];
h q[27];
gck q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(j0==1) p(0.78539816339744828) q[27];
if(j1==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> j2[0];
if(j2==1) x q[27];
h q[27];
gcB q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(j0==1) p(0.39269908169872414) q[27];
if(j1==1) p(0.78539816339744828) q[27];
if(j2==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> j3[0];
if(j3==1) x q[27];
h q[27];
gcD q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(j0==1) p(0.19634954084936207) q[27];
if(j1==1) p(0.39269908169872414) q[27];
if(j2==1) p(0.78539816339744828) q[27];
if(j3==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> j4[0];
if(j4==1) x q[27];
h q[27];
gcZ q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(j0==1) p(0.098174770424681035) q[27];
if(j1==1) p(0.19634954084936207) q[27];
if(j2==1) p(0.39269908169872414) q[27];
if(j3==1) p(0.78539816339744828) q[27];
if(j4==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> j5[0];
if(j5==1) x q[27];
h q[27];
gde q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
h q[27];
measure q[27] -> k0[0];
if(k0==1) x q[27];
h q[27];
gdi q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(k0==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> k1[0];
if(k1==1) x q[27];
h q[27];
gds q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27];
if(k0==1) p(0.78539816339744828) q[27];
if(k1==1) p(1.5707963267948966) q[27];
h q[27];
measure q[27] -> k2[0];
if(k2==1) x q[27];
