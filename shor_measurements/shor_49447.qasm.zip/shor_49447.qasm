OPENQASM 3.0;
include "qelib1.inc";
gate gg a,b,c,d,e,f,g,h,i,j{
ccx j,a,b;ccx j,a,c;ccx j,a,d;ccx j,a,e;ccx j,a,f;ccx j,a,g;ccx j,a,h;ccx j,a,i;}
gate gh a,b,c,d,e,f,g,h{
ccx h,a,b;ccx h,a,c;ccx h,a,d;ccx h,a,e;ccx h,a,f;ccx h,a,g;}
gate gi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gg b,c,e,f,g,i,j,l,n,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,f,h,i,j,k,l,m,o;ccx p,a,o;x a;ccx p,a,o;gh b,c,d,h,i,k,n,o;ccx p,a,o;x a;}
gate ga a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H{
cx r,a;cx r,H;ccx H,a,r;cx s,b;cx s,r;ccx r,b,s;cx t,c;cx t,s;ccx s,c,t;cx u,d;cx u,t;ccx t,d,u;cx v,e;cx v,u;ccx u,e,v;cx w,f;cx w,v;ccx v,f,w;cx x,g;cx x,w;ccx w,g,x;cx y,h;cx y,x;ccx x,h,y;cx z,i;cx z,y;ccx y,i,z;cx A,j;cx A,z;ccx z,j,A;cx B,k;cx B,A;ccx A,k,B;cx C,l;cx C,B;ccx B,l,C;cx D,m;cx D,C;ccx C,m,D;cx E,n;cx E,D;ccx D,n,E;cx F,o;cx F,E;ccx E,o,F;cx G,p;cx G,F;ccx F,p,G;cx G,q;ccx F,p,G;cx G,F;cx F,p;ccx E,o,F;cx F,E;cx E,o;ccx D,n,E;cx E,D;cx D,n;ccx C,m,D;cx D,C;cx C,m;ccx B,l,C;cx C,B;cx B,l;ccx A,k,B;cx B,A;cx A,k;ccx z,j,A;cx A,z;cx z,j;ccx y,i,z;cx z,y;cx y,i;ccx x,h,y;cx y,x;cx x,h;ccx w,g,x;cx x,w;cx w,g;ccx v,f,w;cx w,v;cx v,f;ccx u,e,v;cx v,u;cx u,e;ccx t,d,u;cx u,t;cx t,d;ccx s,c,t;cx t,s;cx s,c;ccx r,b,s;cx s,r;cx r,b;ccx H,a,r;cx r,H;cx H,a;}
gate gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gi a,b,t,u,v,x,y,z,B,D,E,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gi a,b,t,u,v,x,y,z,B,D,E,G,H,I,J,K;}
gate gc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H{
x r;x s;x t;x w;x z;x F;x G;ga a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H;x G;x F;x z;x w;x t;x s;x r;}
gate gd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I{
cx I,r;cx I,s;cx I,t;cx I,w;cx I,z;cx I,F;cx I,G;ga a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H;cx I,G;cx I,F;cx I,z;cx I,w;cx I,t;cx I,s;cx I,r;}
gate gf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I{
inv @ gc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H;cx q,I;gd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I;}
gate gl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gm a,b,c,d,e,f,g,h,i,j,k{
ccx k,a,b;ccx k,a,c;ccx k,a,d;ccx k,a,e;ccx k,a,f;ccx k,a,g;ccx k,a,h;ccx k,a,i;ccx k,a,j;}
gate gn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,c,d,e,f,g,i,k,m,o,q;ccx r,a,q;x b;ccx r,a,q;gm b,d,e,g,h,i,j,l,m,n,q;ccx r,a,q;x a;ccx r,a,q;gm b,d,e,f,g,h,j,l,n,p,q;ccx r,a,q;x a;}
gate go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gn a,b,t,u,v,w,x,y,z,A,B,C,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gn a,b,t,u,v,w,x,y,z,A,B,C,F,G,H,I,J,K;}
gate gq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;go a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gr a,b,c,d,e,f,g,h,i{
ccx i,a,b;ccx i,a,c;ccx i,a,d;ccx i,a,e;ccx i,a,f;ccx i,a,g;ccx i,a,h;}
gate gs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,c,e,f,h,l,o,p;ccx q,a,p;x b;ccx q,a,p;gh b,c,f,g,i,k,m,p;ccx q,a,p;x a;ccx q,a,p;gr b,c,d,i,j,k,l,n,p;ccx q,a,p;x a;}
gate gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gs a,b,t,u,v,x,y,z,A,B,C,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gs a,b,t,u,v,x,y,z,A,B,C,D,E,H,I,J,K;}
gate gv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,d,e,i,j,k,l,p,q;ccx r,a,q;x b;ccx r,a,q;gh b,e,g,h,j,l,n,q;ccx r,a,q;x a;ccx r,a,q;gm b,c,e,f,g,h,k,l,m,o,q;ccx r,a,q;x a;}
gate gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gw a,b,t,u,v,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gw a,b,t,u,v,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,d,f,i,j,k,m,n,o,p,q;ccx r,a,q;x b;ccx r,a,q;gh b,g,k,l,m,o,p,q;ccx r,a,q;x a;ccx r,a,q;gm b,c,e,f,h,i,l,n,o,p,q;ccx r,a,q;x a;}
gate gB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gA a,b,t,u,v,w,x,y,z,A,B,C,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gA a,b,t,u,v,w,x,y,z,A,B,C,E,F,G,I,J,K;}
gate gD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,d,g,h,j,k,l,o,q,r;ccx s,a,r;x b;ccx s,a,r;gg b,c,d,f,i,j,n,o,p,r;ccx s,a,r;x a;ccx s,a,r;gm b,c,d,e,f,g,h,l,m,q,r;ccx s,a,r;x a;}
gate gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gE a,b,t,u,v,w,x,y,z,A,B,C,D,E,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gE a,b,t,u,v,w,x,y,z,A,B,C,D,E,G,H,I,J,K;}
gate gH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gm b,c,d,e,g,i,k,l,n,q,s;ccx t,a,s;x b;ccx t,a,s;gr b,d,e,f,g,i,j,p,s;ccx t,a,s;x a;ccx t,a,s;gm b,d,e,f,h,j,l,m,o,r,s;ccx t,a,s;x a;}
gate gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gI a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gI a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gg b,c,e,g,h,l,m,o,p,r;ccx s,a,r;x b;ccx s,a,r;gr b,f,g,h,i,j,k,q,r;ccx s,a,r;x a;ccx s,a,r;gr b,c,d,i,j,k,l,n,r;ccx s,a,r;x a;}
gate gN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gM a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gM a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,I,J,K;}
gate gP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gr b,c,h,i,j,l,m,q,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,e,g,i,k,l,o,r;ccx s,a,r;x a;ccx s,a,r;gg b,c,d,f,g,k,m,n,p,r;ccx s,a,r;x a;}
gate gR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gQ a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gQ a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,I,J,K;}
gate gT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gX a,b,c,d,e,f,g,h,i,j,k,l,m{
ccx m,a,b;ccx m,a,c;ccx m,a,d;ccx m,a,e;ccx m,a,f;ccx m,a,g;ccx m,a,h;ccx m,a,i;ccx m,a,j;ccx m,a,k;ccx m,a,l;}
gate gY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gg b,d,g,h,j,k,l,o,q,s;ccx t,a,s;x b;ccx t,a,s;gX b,c,d,e,f,h,i,j,k,n,o,p,s;ccx t,a,s;x a;ccx t,a,s;gg b,e,h,i,k,l,m,p,r,s;ccx t,a,s;x a;}
gate gZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gY a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gY a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gbb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbd a,b,c,d,e,f,g,h,i,j,k,l{
ccx l,a,b;ccx l,a,c;ccx l,a,d;ccx l,a,e;ccx l,a,f;ccx l,a,g;ccx l,a,h;ccx l,a,i;ccx l,a,j;ccx l,a,k;}
gate gbe a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,g,h,j,l,m,n,p;ccx q,a,p;x b;ccx q,a,p;gbd b,c,d,e,f,h,i,j,k,l,o,p;ccx q,a,p;x a;ccx q,a,p;gg b,c,d,e,f,g,h,k,m,p;ccx q,a,p;x a;}
gate gbf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbe a,b,t,w,x,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbe a,b,t,w,x,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gbh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbj a,b,c,d,e,f{
ccx f,a,b;ccx f,a,c;ccx f,a,d;ccx f,a,e;}
gate gbk a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gh b,c,d,f,h,i,j,m;ccx n,a,m;x b;ccx n,a,m;gbj b,c,i,j,l,m;ccx n,a,m;x a;ccx n,a,m;gh b,d,e,g,i,j,k,m;ccx n,a,m;x a;}
gate gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbk a,b,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbk a,b,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gbn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbk a,b,w,x,y,z,A,B,C,D,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbk a,b,w,x,y,z,A,B,C,D,E,F,J,K;}
gate gbr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbk a,b,u,v,w,x,y,z,A,B,C,D,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbk a,b,u,v,w,x,y,z,A,B,C,D,J,K;}
gate gbv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbx a,b,c,d,e,f,g{
ccx g,a,b;ccx g,a,c;ccx g,a,d;ccx g,a,e;ccx g,a,f;}
gate gby a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gbx b,c,f,k,l,m,n;ccx o,a,n;x b;ccx o,a,n;gg b,e,g,h,i,j,k,l,m,n;ccx o,a,n;x a;ccx o,a,n;gh b,c,d,f,h,i,j,n;ccx o,a,n;x a;}
gate gbz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gby a,b,t,u,v,w,x,y,z,A,B,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gby a,b,t,u,v,w,x,y,z,A,B,G,H,J,K;}
gate gbB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gbx b,d,e,i,k,m,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,d,e,f,g,h,k,l,o;ccx p,a,o;x a;ccx p,a,o;gbx b,e,f,j,l,n,o;ccx p,a,o;x a;}
gate gbE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbD a,b,t,v,w,x,y,z,A,B,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbD a,b,t,v,w,x,y,z,A,B,E,F,H,I,J,K;}
gate gbG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gl a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gq c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gv e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gz g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gD i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gH k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gL m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gP o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gT o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbb m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbh k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbn i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbr g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbv e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbB c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gbG a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gbJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,c,d,g,h,j,k,m,o,p,q,r;ccx s,a,r;x b;ccx s,a,r;gbd b,c,d,f,i,j,l,m,n,o,q,r;ccx s,a,r;x a;ccx s,a,r;gbd b,c,d,e,f,g,h,l,n,p,q,r;ccx s,a,r;x a;}
gate gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbJ a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbJ a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,I,J,K;}
gate gbM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,c,d,e,f,h,j,k,m,p,q;ccx r,a,q;x b;ccx r,a,q;gX b,c,d,e,f,g,i,j,k,l,m,n,q;ccx r,a,q;x a;ccx r,a,q;gg b,c,d,e,i,j,l,n,o,q;ccx r,a,q;x a;}
gate gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbN a,b,t,u,v,x,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbN a,b,t,u,v,x,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gbQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gg b,c,d,e,h,i,j,k,n,p;ccx q,a,p;x b;ccx q,a,p;gm b,c,e,g,h,j,k,m,n,o,p;ccx q,a,p;x a;ccx q,a,p;gg b,d,e,f,i,j,k,l,o,p;ccx q,a,p;x a;}
gate gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbR a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbR a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,J,K;}
gate gbU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbR a,b,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbR a,b,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gbX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gbY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gg b,f,g,h,k,l,m,n,q,r;ccx s,a,r;x b;ccx s,a,r;gbx b,d,j,m,n,p,r;ccx s,a,r;x a;ccx s,a,r;gX b,c,e,f,g,i,j,k,m,n,o,p,r;ccx s,a,r;x a;}
gate gbZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gbY a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gbY a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gcb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gbZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gbZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gbZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gg b,c,d,f,i,k,l,n,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,h,i,j,k,o,q,r;ccx s,a,r;x a;ccx s,a,r;gg b,d,e,g,j,l,m,o,p,r;ccx s,a,r;x a;}
gate gcd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcc a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcc a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,I,J,K;}
gate gcf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcg a,b,c,d,e,f,g,h,i,j,k,l{
x b;ccx l,a,k;gbj b,c,e,g,h,k;ccx l,a,k;x b;ccx l,a,k;gh b,c,d,e,f,g,j,k;ccx l,a,k;x a;ccx l,a,k;gbj b,d,f,h,i,k;ccx l,a,k;x a;}
gate gch a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcg a,b,t,u,v,w,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcg a,b,t,u,v,w,E,F,G,H,J,K;}
gate gcj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gch a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gch a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gch a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gck a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gbj b,d,f,m,n,p;ccx q,a,p;x b;ccx q,a,p;gm b,c,d,f,h,i,j,k,l,n,p;ccx q,a,p;x a;ccx q,a,p;gbj b,e,g,n,o,p;ccx q,a,p;x a;}
gate gcl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gck a,b,t,v,w,x,y,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gck a,b,t,v,w,x,y,B,C,D,E,F,G,H,I,J,K;}
gate gcn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gco a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,c,d,f,i,j,l,n,q;ccx r,a,q;x b;ccx r,a,q;gbj b,c,h,i,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,d,e,g,j,k,m,o,q;ccx r,a,q;x a;}
gate gcp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gco a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gco a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gcr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gct a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,c,f,g,h,i,j,k,m,p,q,r;ccx s,a,r;x b;ccx s,a,r;gh b,e,i,j,o,p,q,r;ccx s,a,r;x a;ccx s,a,r;gr b,c,d,f,i,j,l,n,r;ccx s,a,r;x a;}
gate gcu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gct a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gct a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gcw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,d,g,h,i,l,n,p;ccx q,a,p;x b;ccx q,a,p;gh b,c,e,f,k,l,m,p;ccx q,a,p;x a;ccx q,a,p;gh b,e,h,i,j,m,o,p;ccx q,a,p;x a;}
gate gcz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcy a,b,t,w,x,y,z,A,B,C,D,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcy a,b,t,w,x,y,z,A,B,C,D,E,F,H,I,J,K;}
gate gcB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gh b,c,e,f,g,j,l,n;ccx o,a,n;x b;ccx o,a,n;gm b,c,d,e,g,i,j,k,l,m,n;ccx o,a,n;x a;ccx o,a,n;gh b,d,f,g,h,k,m,n;ccx o,a,n;x a;}
gate gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcD a,b,u,v,x,y,z,A,B,C,D,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcD a,b,u,v,x,y,z,A,B,C,D,F,G,J,K;}
gate gcG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gh b,e,f,h,j,l,m,n;ccx o,a,n;x b;ccx o,a,n;gm b,c,d,f,g,i,j,k,l,m,n;ccx o,a,n;x a;ccx o,a,n;gh b,c,d,e,f,h,k,n;ccx o,a,n;x a;}
gate gcJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcI a,b,t,w,x,y,z,B,C,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcI a,b,t,w,x,y,z,B,C,D,E,G,H,J,K;}
gate gcL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gh b,c,d,g,i,k,l,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,f,g,h,i,j,k,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,d,e,h,j,l,m,o;ccx p,a,o;x a;}
gate gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcN a,b,v,w,x,y,z,A,B,C,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcN a,b,v,w,x,y,z,A,B,C,E,F,G,H,J,K;}
gate gcQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcN a,b,t,u,v,w,x,y,z,A,C,D,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcN a,b,t,u,v,w,x,y,z,A,C,D,E,F,J,K;}
gate gcU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gcW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gr b,d,g,h,i,l,n,q,r;ccx s,a,r;x b;ccx s,a,r;gbx b,f,k,m,n,o,r;ccx s,a,r;x a;ccx s,a,r;gbd b,c,e,f,g,h,j,k,l,o,p,r;ccx s,a,r;x a;}
gate gcX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcW a,b,t,u,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcW a,b,t,u,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gcZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gcX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gcX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gcX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gbM a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gbQ c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gbU e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gbX g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gcb i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gcf k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gcj m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gcn o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gcr o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcw m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcB k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcG i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcL g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcQ e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcU c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gcZ a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gdc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gm b,c,d,f,g,i,j,k,l,o,p;ccx q,a,p;x b;ccx q,a,p;gbx b,c,d,k,l,n,p;ccx q,a,p;x a;ccx q,a,p;gbd b,c,d,e,f,h,i,k,l,m,n,p;ccx q,a,p;x a;}
gate gdd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdc a,b,t,u,v,w,x,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdc a,b,t,u,v,w,x,B,C,D,E,F,G,H,I,J,K;}
gate gdf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gbd b,c,d,e,g,h,i,j,m,o,p,s;ccx t,a,s;x b;ccx t,a,s;gbd b,c,e,h,i,j,l,m,n,o,r,s;ccx t,a,s;x a;ccx t,a,s;gbd b,d,e,f,h,i,j,k,n,p,q,s;ccx t,a,s;x a;}
gate gdh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdg a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdg a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gdj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,c,e,g,h,j,l,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,d,e,f,g,n,o,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,d,f,h,i,k,m,p,q;ccx r,a,q;x a;}
gate gdl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdk a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdk a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,J,K;}
gate gdn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,d,f,h,i,k,m,o,q;ccx r,a,q;x b;ccx r,a,q;gm b,c,d,f,h,j,k,l,m,n,q;ccx r,a,q;x a;ccx r,a,q;gr b,e,g,i,j,l,n,p,q;ccx r,a,q;x a;}
gate gdp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdo a,b,t,v,w,x,y,z,A,B,C,D,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdo a,b,t,v,w,x,y,z,A,B,C,D,E,F,H,I,J,K;}
gate gdr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gds a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,c,f,h,k,m,o,p,q;ccx r,a,q;x b;ccx r,a,q;gm b,e,g,i,j,l,m,n,o,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,c,d,f,h,j,k,n,q;ccx r,a,q;x a;}
gate gdt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gds a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gds a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,J,K;}
gate gdv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,c,d,f,h,k,l,o,q;ccx r,a,q;x b;ccx r,a,q;gh b,c,j,k,n,o,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,d,e,g,i,l,m,p,q;ccx r,a,q;x a;}
gate gdx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdw a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdw a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gdz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gr b,e,f,h,j,k,l,o,p;ccx q,a,p;x b;ccx q,a,p;gg b,d,e,f,g,i,j,k,n,p;ccx q,a,p;x a;ccx q,a,p;gr b,c,e,i,j,l,m,n,p;ccx q,a,p;x a;}
gate gdB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdA a,b,t,u,w,x,y,z,A,B,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdA a,b,t,u,w,x,y,z,A,B,E,F,G,H,I,J,K;}
gate gdD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gg b,c,d,f,h,i,j,k,n,p;ccx q,a,p;x b;ccx q,a,p;gr b,c,i,j,k,m,n,o,p;ccx q,a,p;x a;ccx q,a,p;gg b,d,e,g,i,j,k,l,o,p;ccx q,a,p;x a;}
gate gdF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdE a,b,t,u,v,w,x,y,z,A,B,C,D,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdE a,b,t,u,v,w,x,y,z,A,B,C,D,G,H,J,K;}
gate gdH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,c,e,g,h,j,k,l,m,n,q;ccx r,a,q;x b;ccx r,a,q;gbd b,c,d,e,f,g,k,l,m,n,p,q;ccx r,a,q;x a;ccx r,a,q;gm b,d,f,h,i,k,l,m,n,o,q;ccx r,a,q;x a;}
gate gdJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdI a,b,t,u,v,w,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdI a,b,t,u,v,w,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gdL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
ccx o,a,b;ccx o,a,c;ccx o,a,d;ccx o,a,e;ccx o,a,f;ccx o,a,g;ccx o,a,h;ccx o,a,i;ccx o,a,j;ccx o,a,k;ccx o,a,l;ccx o,a,m;ccx o,a,n;}
gate gdO a,b,c,d,e,f,g,h,i,j,k,l,m,n{
ccx n,a,b;ccx n,a,c;ccx n,a,d;ccx n,a,e;ccx n,a,f;ccx n,a,g;ccx n,a,h;ccx n,a,i;ccx n,a,j;ccx n,a,k;ccx n,a,l;ccx n,a,m;}
gate gdP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gdN b,c,d,f,g,h,i,j,k,l,m,n,o,p,s;ccx t,a,s;x b;ccx t,a,s;gdO b,c,g,h,i,j,k,l,m,n,o,p,r,s;ccx t,a,s;x a;ccx t,a,s;gdN b,d,e,g,h,i,j,k,l,m,n,o,p,q,s;ccx t,a,s;x a;}
gate gdQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdP a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdP a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gdS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdU a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gr b,e,f,g,h,i,j,l,m;ccx n,a,m;x b;ccx n,a,m;gbx b,d,e,h,j,k,m;ccx n,a,m;x a;ccx n,a,m;gbj b,c,g,i,l,m;ccx n,a,m;x a;}
gate gdV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdU a,b,t,u,v,w,x,z,A,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdU a,b,t,u,v,w,x,z,A,G,H,I,J,K;}
gate gdX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gdV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gdV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gdV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gdZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,c,d,e,g,h,k,m,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,e,h,j,k,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gr b,d,e,f,h,i,l,n,o;ccx p,a,o;x a;}
gate gea a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gdZ a,b,t,u,v,w,x,y,z,A,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gdZ a,b,t,u,v,w,x,y,z,A,E,F,G,H,J,K;}
gate gec a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gea a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gea a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gea a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gee a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,c,d,f,h,i,j,k,m,n,q,r;ccx s,a,r;x b;ccx s,a,r;gm b,c,d,g,h,i,k,l,m,p,r;ccx s,a,r;x a;ccx s,a,r;gbd b,c,d,e,f,h,j,l,n,o,p,r;ccx s,a,r;x a;}
gate gef a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gee a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gee a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,I,J,K;}
gate geh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gef a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gef a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gef a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gej a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,e,f,i,j,k,l,n,o,p,q;ccx r,a,q;x b;ccx r,a,q;gg b,d,e,f,g,h,l,o,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,c,e,k,l,m,o,p,q;ccx r,a,q;x a;}
gate gek a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gej a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gej a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,I,J,K;}
gate gem a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gek a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gek a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gek a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,d,g,h,i,j,l,m,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,f,g,i,j,m,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,e,h,i,j,k,m,n,p,r;ccx s,a,r;x a;}
gate gep a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geo a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geo a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate ger a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gep a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gep a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gep a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate get a,b,c,d,e{
ccx e,a,b;ccx e,a,c;ccx e,a,d;}
gate geu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gr b,c,e,f,m,n,p,q,s;ccx t,a,s;x b;ccx t,a,s;get b,k,l,r,s;ccx t,a,s;x a;ccx t,a,s;gm b,c,d,g,h,i,j,l,m,o,s;ccx t,a,s;x a;}
gate gev a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geu a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geu a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gex a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gev a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gev a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gev a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gez a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gdf a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdj c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdn e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdr g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdv i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdz k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdD m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gdH o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gdL o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gdS m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gdX k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gec i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ geh g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gem e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ger c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gex a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate geA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gr b,d,f,g,i,j,k,n,p;ccx q,a,p;x b;ccx q,a,p;gbx b,c,e,i,k,m,p;ccx q,a,p;x a;ccx q,a,p;gr b,e,g,h,j,k,l,o,p;ccx q,a,p;x a;}
gate geB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geA a,b,t,w,x,y,z,A,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geA a,b,t,w,x,y,z,A,C,D,E,F,G,H,I,J,K;}
gate geD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gm b,c,f,g,h,i,n,o,p,q,s;ccx t,a,s;x b;ccx t,a,s;gbx b,e,i,n,p,r,s;ccx t,a,s;x a;ccx t,a,s;gbd b,c,d,f,i,j,k,l,m,n,p,s;ccx t,a,s;x a;}
gate geF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geE a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geE a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate geH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,d,e,g,i,j,k,l,m,n,p,r;ccx s,a,r;x b;ccx s,a,r;gbd b,c,d,f,g,i,j,l,m,n,p,r;ccx s,a,r;x a;ccx s,a,r;gbd b,e,f,h,j,k,l,m,n,o,q,r;ccx s,a,r;x a;}
gate geJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geI a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geI a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,I,J,K;}
gate geL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gm b,c,g,h,j,k,l,m,n,o,p;ccx q,a,p;x b;ccx q,a,p;gg b,c,e,i,j,k,m,n,o,p;ccx q,a,p;x a;ccx q,a,p;gbd b,c,d,f,g,h,j,l,m,n,o,p;ccx q,a,p;x a;}
gate geN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geM a,b,t,u,v,w,x,y,z,B,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geM a,b,t,u,v,w,x,y,z,B,D,E,F,G,I,J,K;}
gate geP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gm b,c,d,e,f,i,k,l,m,n,o;ccx p,a,o;x b;ccx p,a,o;gm b,c,d,e,f,g,j,k,l,n,o;ccx p,a,o;x a;ccx p,a,o;gm b,c,d,e,g,h,i,k,m,n,o;ccx p,a,o;x a;}
gate geR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geQ a,b,t,u,v,w,x,y,z,A,B,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geQ a,b,t,u,v,w,x,y,z,A,B,F,G,I,J,K;}
gate geT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geU a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gr b,c,d,e,g,h,i,l,m;ccx n,a,m;x b;ccx n,a,m;gbx b,c,d,e,i,j,m;ccx n,a,m;x a;ccx n,a,m;gr b,c,d,e,f,g,j,k,m;ccx n,a,m;x a;}
gate geV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geU a,b,t,u,v,y,z,A,B,C,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geU a,b,t,u,v,y,z,A,B,C,H,I,J,K;}
gate geX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate geY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,d,e,f,i,j,k,n,o;ccx p,a,o;x b;ccx p,a,o;gbx b,e,f,g,k,l,o;ccx p,a,o;x a;ccx p,a,o;gr b,c,e,g,h,i,l,m,o;ccx p,a,o;x a;}
gate geZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
geY a,b,t,u,v,w,x,y,z,A,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;geY a,b,t,u,v,w,x,y,z,A,D,E,H,I,J,K;}
gate gfb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
geZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ geZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;geZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,d,f,h,i,j,k,n,o;ccx p,a,o;x b;ccx p,a,o;gbx b,g,h,i,k,l,o;ccx p,a,o;x a;ccx p,a,o;gr b,c,e,f,h,j,l,m,o;ccx p,a,o;x a;}
gate gfd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfc a,b,t,u,v,w,x,y,z,A,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfc a,b,t,u,v,w,x,y,z,A,F,G,H,I,J,K;}
gate gff a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gg b,d,g,h,i,l,n,p,r,s;ccx t,a,s;x b;ccx t,a,s;gr b,f,k,m,n,o,p,q,s;ccx t,a,s;x a;ccx t,a,s;gbd b,c,e,f,g,h,j,k,l,o,r,s;ccx t,a,s;x a;}
gate gfh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfg a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfg a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gfj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,f,g,i,j,l,o,p;ccx q,a,p;x b;ccx q,a,p;gr b,d,h,i,j,k,l,m,p;ccx q,a,p;x a;ccx q,a,p;gg b,c,e,f,g,i,k,m,n,p;ccx q,a,p;x a;}
gate gfm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfl a,b,t,u,w,x,y,z,B,C,D,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfl a,b,t,u,w,x,y,z,B,C,D,E,F,H,I,J,K;}
gate gfo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gh b,c,d,g,h,j,m,o;ccx p,a,o;x b;ccx p,a,o;gh b,c,f,g,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,d,e,h,i,k,n,o;ccx p,a,o;x a;}
gate gfr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfq a,b,v,w,x,y,z,A,B,C,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfq a,b,v,w,x,y,z,A,B,C,D,E,G,H,J,K;}
gate gft a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfq a,b,t,u,v,w,x,y,z,A,B,C,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfq a,b,t,u,v,w,x,y,z,A,B,C,E,F,J,K;}
gate gfx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gh b,d,f,k,l,n,q,r;ccx s,a,r;x b;ccx s,a,r;gr b,g,i,j,l,m,n,o,r;ccx s,a,r;x a;ccx s,a,r;gm b,c,e,f,h,i,j,m,o,p,r;ccx s,a,r;x a;}
gate gfA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfz a,b,t,u,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfz a,b,t,u,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gfC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,d,e,f,h,j,k,n,o;ccx p,a,o;x b;ccx p,a,o;gr b,e,f,g,i,j,k,l,o;ccx p,a,o;x a;ccx p,a,o;gh b,c,e,i,j,l,m,o;ccx p,a,o;x a;}
gate gfF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfE a,b,t,u,v,x,y,z,A,B,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfE a,b,t,u,v,x,y,z,A,B,D,E,H,I,J,K;}
gate gfH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gr b,c,f,g,h,i,j,m,n;ccx o,a,n;x b;ccx o,a,n;gr b,c,e,f,g,h,j,k,n;ccx o,a,n;x a;ccx o,a,n;gr b,c,d,f,g,i,k,l,n;ccx o,a,n;x a;}
gate gfK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfJ a,b,t,u,v,w,y,z,A,B,C,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfJ a,b,t,u,v,w,y,z,A,B,C,H,I,J,K;}
gate gfM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gbx b,d,g,h,j,l,n;ccx o,a,n;x b;ccx o,a,n;gh b,c,d,f,i,j,k,n;ccx o,a,n;x a;ccx o,a,n;gbx b,e,h,i,k,m,n;ccx o,a,n;x a;}
gate gfP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfO a,b,t,v,w,y,z,A,B,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfO a,b,t,v,w,y,z,A,B,F,G,H,I,J,K;}
gate gfR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
geD a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;geH c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;geL e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;geP g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;geT i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;geX k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gfb m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gff o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gfj o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gfo m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gft k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gfx i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gfC g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gfH e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gfM c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gfR a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gfU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gr b,c,d,e,h,l,n,o,p;ccx q,a,p;x b;ccx q,a,p;gbd b,d,e,f,g,i,j,k,m,n,o,p;ccx q,a,p;x a;ccx q,a,p;gg b,c,d,e,g,h,j,k,l,p;ccx q,a,p;x a;}
gate gfV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfU a,b,t,u,v,w,y,z,A,B,C,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfU a,b,t,u,v,w,y,z,A,B,C,D,E,G,H,J,K;}
gate gfX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gfY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gg b,c,d,e,h,i,k,l,m,p;ccx q,a,p;x b;ccx q,a,p;gr b,c,e,g,h,l,m,o,p;ccx q,a,p;x a;ccx q,a,p;gg b,d,e,f,i,j,l,m,n,p;ccx q,a,p;x a;}
gate gfZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfY a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfY a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,J,K;}
gate ggb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gfZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gfZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gfZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gfY a,b,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gfY a,b,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gge a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,e,f,g,i,j,k,m,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,d,e,g,j,k,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,f,g,h,j,k,l,n,p,r;ccx s,a,r;x a;}
gate ggg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggf a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggf a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate ggi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,e,h,i,j,k,l,m,o,p,q;ccx r,a,q;x b;ccx r,a,q;gg b,d,e,f,g,i,k,m,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,c,h,j,l,m,n,p,q;ccx r,a,q;x a;}
gate ggk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggj a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggj a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,I,J,K;}
gate ggm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gg b,c,d,f,g,l,m,n,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,d,f,h,i,j,k,n,p,q;ccx r,a,q;x a;ccx r,a,q;gm b,c,d,e,f,i,j,k,l,n,q;ccx r,a,q;x a;}
gate ggo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggn a,b,t,u,v,w,x,y,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggn a,b,t,u,v,w,x,y,B,C,D,E,F,G,H,I,J,K;}
gate ggq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,d,e,f,g,j,k,l,m,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,d,g,h,i,l,m,o,q;ccx r,a,q;x a;ccx r,a,q;gm b,e,f,g,h,k,l,m,n,p,q;ccx r,a,q;x a;}
gate ggs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggr a,b,t,u,v,w,x,y,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggr a,b,t,u,v,w,x,y,B,C,D,E,F,G,H,I,J,K;}
gate ggu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,g,i,k,l,m,o,p,q,r;ccx s,a,r;x b;ccx s,a,r;gg b,c,e,h,j,k,l,p,q,r;ccx s,a,r;x a;ccx s,a,r;gX b,c,d,f,g,h,i,k,m,n,p,q,r;ccx s,a,r;x a;}
gate ggw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggv a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggv a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,I,J,K;}
gate ggy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gr b,c,d,g,i,j,l,n,q;ccx r,a,q;x b;ccx r,a,q;gh b,c,f,g,h,i,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,d,e,h,j,k,m,o,q;ccx r,a,q;x a;}
gate ggA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggz a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggz a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,J,K;}
gate ggC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gh b,d,i,k,l,n,q,r;ccx s,a,r;x b;ccx s,a,r;gbx b,f,g,h,i,p,r;ccx s,a,r;x a;ccx s,a,r;gbd b,c,e,f,g,i,j,k,m,o,p,r;ccx s,a,r;x a;}
gate ggF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggE a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggE a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,I,J,K;}
gate ggH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gbx b,e,h,j,k,o,p;ccx q,a,p;x b;ccx q,a,p;gbx b,d,e,f,g,m,p;ccx q,a,p;x a;ccx q,a,p;gh b,c,h,i,j,l,n,p;ccx q,a,p;x a;}
gate ggK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggJ a,b,t,u,v,w,x,y,B,C,D,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggJ a,b,t,u,v,w,x,y,B,C,D,E,F,H,I,J,K;}
gate ggM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggO a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gbx b,c,e,g,h,k,m;ccx n,a,m;x b;ccx n,a,m;gg b,c,d,e,f,g,j,k,l,m;ccx n,a,m;x a;ccx n,a,m;gbx b,d,f,h,i,l,m;ccx n,a,m;x a;}
gate ggP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggO a,b,t,u,w,x,A,B,C,D,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggO a,b,t,u,w,x,A,B,C,D,G,H,J,K;}
gate ggR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gr b,c,d,f,h,k,l,m,p;ccx q,a,p;x b;ccx q,a,p;gbx b,c,j,k,m,o,p;ccx q,a,p;x a;ccx q,a,p;gr b,d,e,g,i,l,m,n,p;ccx q,a,p;x a;}
gate ggU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggT a,b,v,w,x,y,z,A,B,C,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggT a,b,v,w,x,y,z,A,B,C,E,F,G,H,I,J,K;}
gate ggW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ggY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggT a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggT a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,J,K;}
gate gha a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ggY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ggY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ggY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gh b,e,f,g,k,m,p,q;ccx r,a,q;x b;ccx r,a,q;gm b,d,e,f,g,h,j,l,m,n,q;ccx r,a,q;x a;ccx r,a,q;gm b,c,e,f,h,i,j,k,n,o,q;ccx r,a,q;x a;}
gate ghd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghc a,b,t,u,w,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghc a,b,t,u,w,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate ghf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gh b,c,e,f,i,k,m,o;ccx p,a,o;x b;ccx p,a,o;gbd b,c,d,e,h,i,j,k,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,d,f,g,j,l,n,o;ccx p,a,o;x a;}
gate ghi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghh a,b,u,v,w,x,y,z,B,C,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghh a,b,u,v,w,x,y,z,B,C,D,E,G,H,J,K;}
gate ghk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gfX a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ggb c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gge e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ggi g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ggm i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ggq k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ggu m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ggy o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ ggC o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ggH m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ggM k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ggR i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ggW g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gha e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ghf c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ghk a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate ghn a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gh b,c,d,f,g,i,j,m;ccx n,a,m;x b;ccx n,a,m;gbj b,c,g,j,l,m;ccx n,a,m;x a;ccx n,a,m;gh b,d,e,g,h,j,k,m;ccx n,a,m;x a;}
gate gho a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghn a,b,v,w,x,y,z,A,B,C,D,E,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghn a,b,v,w,x,y,z,A,B,C,D,E,J,K;}
gate ghq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gho a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gho a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gho a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghn a,b,x,y,z,A,B,C,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghn a,b,x,y,z,A,B,C,D,E,F,G,J,K;}
gate ght a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghn a,b,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghn a,b,z,A,B,C,D,E,F,G,H,I,J,K;}
gate ghw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gg b,c,e,f,h,i,j,m,n,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,d,e,i,j,l,m,p,q;ccx r,a,q;x a;ccx r,a,q;gg b,d,f,g,i,j,k,n,o,q;ccx r,a,q;x a;}
gate ghy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghx a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghx a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate ghA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gg b,d,e,f,h,i,j,m,n,o;ccx p,a,o;x b;ccx p,a,o;gr b,c,d,h,j,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,c,e,g,h,j,k,o;ccx p,a,o;x a;}
gate ghC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghB a,b,t,v,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghB a,b,t,v,y,z,A,B,C,D,E,F,G,H,J,K;}
gate ghE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gh b,c,e,g,h,j,k,n;ccx o,a,n;x b;ccx o,a,n;gr b,c,d,e,f,g,k,m,n;ccx o,a,n;x a;ccx o,a,n;gh b,d,f,h,i,k,l,n;ccx o,a,n;x a;}
gate ghG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghF a,b,u,v,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghF a,b,u,v,z,A,B,C,D,E,F,G,H,J,K;}
gate ghI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,d,i,j,k,m,n,p;ccx q,a,p;x b;ccx q,a,p;gg b,c,e,f,g,h,i,j,o,p;ccx q,a,p;x a;ccx q,a,p;gr b,c,d,f,g,h,k,l,p;ccx q,a,p;x a;}
gate ghK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghJ a,b,t,w,x,y,z,A,B,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghJ a,b,t,w,x,y,z,A,B,D,E,F,G,H,I,J,K;}
gate ghM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gr b,c,e,g,h,i,l,m,p;ccx q,a,p;x b;ccx q,a,p;gm b,c,d,e,f,g,i,k,l,o,p;ccx q,a,p;x a;ccx q,a,p;gr b,d,f,h,i,j,m,n,p;ccx q,a,p;x a;}
gate ghO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghN a,b,u,v,x,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghN a,b,u,v,x,y,z,A,B,C,D,F,G,H,I,J,K;}
gate ghQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gm b,c,e,f,g,h,j,k,m,o,p;ccx q,a,p;x b;ccx q,a,p;gm b,c,f,h,i,j,k,l,m,n,p;ccx q,a,p;x a;ccx q,a,p;gr b,c,d,g,i,j,l,o,p;ccx q,a,p;x a;}
gate ghS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghR a,b,t,u,v,w,x,y,z,B,C,D,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghR a,b,t,u,v,w,x,y,z,B,C,D,G,H,I,J,K;}
gate ghU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate ghW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gr b,c,f,g,i,k,l,n,p;ccx q,a,p;x b;ccx q,a,p;gbx b,e,h,j,k,n,p;ccx q,a,p;x a;ccx q,a,p;gr b,d,g,h,j,l,m,o,p;ccx q,a,p;x a;}
gate ghX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghW a,b,t,u,v,w,x,y,B,C,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghW a,b,t,u,v,w,x,y,B,C,E,F,G,H,I,J,K;}
gate ghZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
ghX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ ghX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;ghX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gib a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gbx b,e,g,i,j,m,o;ccx p,a,o;x b;ccx p,a,o;gbx b,c,d,g,i,l,o;ccx p,a,o;x a;ccx p,a,o;gbx b,f,h,j,k,n,o;ccx p,a,o;x a;}
gate gic a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gib a,b,t,w,x,y,A,B,C,D,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gib a,b,t,w,x,y,A,B,C,D,E,F,H,I,J,K;}
gate gie a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gic a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gic a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gic a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gig a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggO a,b,v,w,y,z,A,B,C,D,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggO a,b,v,w,y,z,A,B,C,D,F,G,J,K;}
gate gii a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gig a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gig a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gig a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gik a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ggO a,b,t,u,w,x,y,z,A,B,D,E,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ggO a,b,t,u,w,x,y,z,A,B,D,E,J,K;}
gate gim a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gik a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gik a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gik a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gio a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gh b,c,e,f,h,k,l,o;ccx p,a,o;x b;ccx p,a,o;gh b,c,d,e,j,k,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,d,f,g,i,l,m,o;ccx p,a,o;x a;}
gate gip a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gio a,b,v,w,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gio a,b,v,w,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gir a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gip a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gip a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gip a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate git a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gio a,b,t,u,w,x,y,z,A,B,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gio a,b,t,u,w,x,y,z,A,B,D,E,F,G,J,K;}
gate giv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
git a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ git a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;git a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gix a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gh b,c,d,f,g,j,k,n;ccx o,a,n;x b;ccx o,a,n;gbx b,c,g,i,j,m,n;ccx o,a,n;x a;ccx o,a,n;gh b,d,e,g,h,k,l,n;ccx o,a,n;x a;}
gate giy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gix a,b,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gix a,b,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate giA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate giC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
ghq a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ght c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ghw e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ghA g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ghE i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ghI k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ghM m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;ghQ o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ ghU o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ ghZ m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gie k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gii i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gim g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gir e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ giv c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ giA a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate giD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,c,e,f,h,i,k,l,m,n,o,r;ccx s,a,r;x b;ccx s,a,r;gm b,c,d,e,i,l,m,n,o,q,r;ccx s,a,r;x a;ccx s,a,r;gbd b,d,f,g,i,j,l,m,n,o,p,r;ccx s,a,r;x a;}
gate giE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
giD a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;giD a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate giG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate giH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,e,f,g,h,k,m,n,o,r;ccx s,a,r;x b;ccx s,a,r;gX b,c,d,e,g,h,j,k,l,m,o,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,f,g,h,i,l,n,o,p,r;ccx s,a,r;x a;}
gate giI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
giH a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;giH a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,I,J,K;}
gate giK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate giL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,e,f,i,j,k,l,m,p,r;ccx s,a,r;x b;ccx s,a,r;gX b,c,d,e,h,i,k,l,m,o,p,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,f,g,j,k,l,m,n,q,r;ccx s,a,r;x a;}
gate giM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
giL a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;giL a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate giO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate giP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,e,g,h,j,k,l,m,n,q,r;ccx s,a,r;x b;ccx s,a,r;gm b,d,e,f,i,j,k,m,n,p,r;ccx s,a,r;x a;ccx s,a,r;gg b,c,i,j,l,m,n,o,p,r;ccx s,a,r;x a;}
gate giQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
giP a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;giP a,b,t,u,v,w,x,y,z,B,C,D,E,F,G,H,I,J,K;}
gate giS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate giT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gm b,c,d,f,g,i,k,n,o,p,s;ccx t,a,s;x b;ccx t,a,s;gh b,c,g,m,n,p,r,s;ccx t,a,s;x a;ccx t,a,s;gm b,d,e,g,h,j,l,o,p,q,s;ccx t,a,s;x a;}
gate giU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
giT a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;giT a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate giW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate giX a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gbx b,c,e,g,i,k,m;ccx n,a,m;x b;ccx n,a,m;gbd b,c,d,e,f,g,h,i,j,k,l,m;ccx n,a,m;x a;ccx n,a,m;gbx b,d,f,h,j,l,m;ccx n,a,m;x a;}
gate giY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
giX a,b,t,u,v,w,z,A,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;giX a,b,t,u,v,w,z,A,D,E,G,H,J,K;}
gate gja a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
giY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ giY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;giY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjb a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gbx b,e,g,k,l,o,p;ccx q,a,p;x b;ccx q,a,p;gg b,d,e,f,h,i,j,l,m,p;ccx q,a,p;x a;ccx q,a,p;gbj b,c,k,m,n,p;ccx q,a,p;x a;}
gate gjc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjb a,b,t,u,v,w,x,y,z,A,B,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjb a,b,t,u,v,w,x,y,z,A,B,F,G,H,I,J,K;}
gate gje a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
ghn a,b,t,u,v,w,x,y,z,A,B,C,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;ghn a,b,t,u,v,w,x,y,z,A,B,C,J,K;}
gate gjh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gji a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gbx b,c,e,g,i,j,m;ccx n,a,m;x b;ccx n,a,m;gg b,c,d,e,f,g,h,i,l,m;ccx n,a,m;x a;ccx n,a,m;gbx b,d,f,h,j,k,m;ccx n,a,m;x a;}
gate gjj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gji a,b,u,v,w,x,z,A,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gji a,b,u,v,w,x,z,A,F,G,H,I,J,K;}
gate gjl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gg b,d,e,g,i,j,k,m,n,p;ccx q,a,p;x b;ccx q,a,p;gr b,c,d,f,h,i,j,o,p;ccx q,a,p;x a;ccx q,a,p;gbx b,c,e,g,k,l,p;ccx q,a,p;x a;}
gate gjo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjn a,b,t,u,v,w,y,z,A,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjn a,b,t,u,v,w,y,z,A,D,E,F,G,H,I,J,K;}
gate gjq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gdO b,c,e,f,g,h,j,k,l,n,o,p,q,s;ccx t,a,s;x b;ccx t,a,s;gbx b,g,l,o,p,r,s;ccx t,a,s;x a;ccx t,a,s;gg b,c,d,g,i,l,m,o,p,s;ccx t,a,s;x a;}
gate gjt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjs a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjs a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gjv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gm b,c,f,g,h,k,l,m,n,q,s;ccx t,a,s;x b;ccx t,a,s;gbx b,e,j,m,n,p,s;ccx t,a,s;x a;ccx t,a,s;gm b,d,g,h,i,l,m,n,o,r,s;ccx t,a,s;x a;}
gate gjy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjx a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjx a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gjA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjC a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gbj b,d,e,i,k,m;ccx n,a,m;x b;ccx n,a,m;gbx b,c,f,g,h,j,m;ccx n,a,m;x a;ccx n,a,m;gbj b,e,f,j,l,m;ccx n,a,m;x a;}
gate gjD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjC a,b,t,w,x,y,B,C,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjC a,b,t,w,x,y,B,C,D,E,H,I,J,K;}
gate gjF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjH a,b,c,d,e,f,g,h,i,j,k,l{
x b;ccx l,a,k;gbj b,c,d,g,i,k;ccx l,a,k;x b;ccx l,a,k;gh b,c,f,g,h,i,j,k;ccx l,a,k;x a;ccx l,a,k;gbj b,d,e,h,j,k;ccx l,a,k;x a;}
gate gjI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjH a,b,u,v,w,x,B,C,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjH a,b,u,v,w,x,B,C,F,G,J,K;}
gate gjK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gg b,c,e,g,h,i,k,m,n,o;ccx p,a,o;x b;ccx p,a,o;gg b,f,g,h,j,k,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gbj b,c,d,i,l,o;ccx p,a,o;x a;}
gate gjN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjM a,b,t,u,v,w,x,z,A,B,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjM a,b,t,u,v,w,x,z,A,B,D,E,G,H,J,K;}
gate gjP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gbd b,c,d,e,f,g,h,i,k,m,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,d,e,g,i,k,l,m,n,q;ccx r,a,q;x a;ccx r,a,q;gbd b,d,e,f,g,h,i,j,l,n,p,q;ccx r,a,q;x a;}
gate gjS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjR a,b,t,u,v,w,x,y,z,A,B,C,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjR a,b,t,u,v,w,x,y,z,A,B,C,E,F,H,I,J,K;}
gate gjU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gjS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gjS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gjS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gjW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
giG a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giK c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giO e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giS g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giW i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gja k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gje m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gjh o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gjl o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjq m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjv k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjA i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjF g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjK e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjP c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjU a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gjX a,b,c{
ccx c,a,b;}
gate gjY a,b,c,d{
ccx d,a,b;ccx d,a,c;}
gate gjZ a,b,c,d,e,f{
x b;ccx f,a,e;gjX b,c,e;ccx f,a,e;x b;ccx f,a,e;gjY b,c,d,e;ccx f,a,e;x a;ccx f,a,e;gjX b,d,e;ccx f,a,e;x a;}
gate gka a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,B,C,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,B,C,J,K;}
gate gkc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gka a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gka a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gka a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,D,E,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,D,E,J,K;}
gate gkf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,F,G,J,K;}
gate gki a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,H,I,J,K;}
gate gkl a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,z,A,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,z,A,J,K;}
gate gko a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,x,y,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,x,y,J,K;}
gate gks a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gku a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,v,w,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,v,w,J,K;}
gate gkw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gku a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gku a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gku a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gky a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,t,u,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,t,u,J,K;}
gate gkA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gky a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gky a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gky a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gkc a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkf c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gki e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkl g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giG i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giK k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giO m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giS o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gko o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gks m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkw k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkA i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjl g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjq e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjv c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjA a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gkF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gks a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gko c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkc e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkf g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gki i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkl k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giG m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giK o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gkf o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkc m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gko k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gks i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkw g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkA e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjl c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjq a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gkH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gkw a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gks c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gko e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkc g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkf i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gki k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkl m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;giG o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gki o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkf m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkc k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gko i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gks g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkw e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkA c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gjl a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gkI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,u,v,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,u,v,J,K;}
gate gkK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,w,x,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,w,x,J,K;}
gate gkN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,y,z,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,y,z,J,K;}
gate gkQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,A,B,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,A,B,J,K;}
gate gkT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,C,D,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,C,D,J,K;}
gate gkW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gkX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,E,F,J,K;}
gate gkZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gkX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gkX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gkX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gla a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gjZ a,b,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gjZ a,b,G,H,J,K;}
gate glc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gla a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gla a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gla a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gld a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gjX b,m,n;ccx o,a,n;x b;ccx o,a,n;gX b,c,d,e,f,g,h,i,j,k,l,m,n;ccx o,a,n;x a;ccx o,a,n;gbd b,c,d,e,f,g,h,i,j,k,l,n;ccx o,a,n;x a;}
gate gle a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gld a,b,t,w,x,z,A,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gld a,b,t,w,x,z,A,C,D,E,F,G,I,J,K;}
gate glg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gle a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gle a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gle a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glo a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;gbx b,d,e,f,g,h,i;ccx j,a,i;x b;ccx j,a,i;gh b,c,d,e,f,g,h,i;ccx j,a,i;x a;ccx j,a,i;gjX b,c,i;ccx j,a,i;x a;}
gate glp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glo a,b,t,v,x,A,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glo a,b,t,v,x,A,G,H,J,K;}
gate glr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gkK a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkN c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkQ e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkT g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkW i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gkZ k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glc m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glg o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ glc o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkZ m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkW k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkT i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkQ g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkN e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gkK c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ glr a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate glu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gg b,c,d,g,h,i,m,o,p,q;ccx r,a,q;x b;ccx r,a,q;gr b,d,g,h,m,n,o,p,q;ccx r,a,q;x a;ccx r,a,q;gbd b,c,d,e,f,g,h,j,k,l,m,q;ccx r,a,q;x a;}
gate glv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glu a,b,t,u,v,w,x,y,z,A,B,C,D,E,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glu a,b,t,u,v,w,x,y,z,A,B,C,D,E,G,H,J,K;}
gate glx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gly a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gbd b,c,d,e,f,g,h,j,k,l,m,p;ccx q,a,p;x b;ccx q,a,p;gm b,c,e,f,g,h,k,l,m,o,p;ccx q,a,p;x a;ccx q,a,p;gbd b,d,e,f,g,h,i,k,l,m,n,p;ccx q,a,p;x a;}
gate glz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gly a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gly a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,J,K;}
gate glB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gly a,b,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gly a,b,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate glE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,e,f,g,i,k,l,n,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,d,e,g,l,o,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,f,g,h,j,l,m,o,p,r;ccx s,a,r;x a;}
gate glG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glF a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glF a,b,t,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate glI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,e,f,g,h,j,k,n,o,r;ccx s,a,r;x b;ccx s,a,r;gm b,c,d,e,g,h,k,m,n,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,f,g,h,i,k,l,o,p,r;ccx s,a,r;x a;}
gate glK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glJ a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glJ a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate glM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gm b,d,e,f,g,h,j,k,n,o,p;ccx q,a,p;x b;ccx q,a,p;gbd b,c,d,e,f,h,i,j,m,n,o,p;ccx q,a,p;x a;ccx q,a,p;gbx b,c,g,h,k,l,p;ccx q,a,p;x a;}
gate glO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glN a,b,t,v,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glN a,b,t,v,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate glQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glR a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gbx b,c,e,f,i,j,m;ccx n,a,m;x b;ccx n,a,m;gh b,c,d,e,h,i,l,m;ccx n,a,m;x a;ccx n,a,m;gbx b,d,f,g,j,k,m;ccx n,a,m;x a;}
gate glS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glR a,b,u,v,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glR a,b,u,v,A,B,C,D,E,F,G,H,J,K;}
gate glU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gbx b,d,i,j,m,n,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,e,f,g,h,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gr b,c,d,f,g,h,i,k,o;ccx p,a,o;x a;}
gate glW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glV a,b,t,w,x,y,z,A,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glV a,b,t,w,x,y,z,A,C,D,E,F,G,H,J,K;}
gate glY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
glW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ glW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;glW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate glZ a,b,c,d,e,f,g,h,i,j{
x b;ccx j,a,i;get b,c,e,f,i;ccx j,a,i;x b;ccx j,a,i;gbj b,c,d,e,h,i;ccx j,a,i;x a;ccx j,a,i;get b,d,f,g,i;ccx j,a,i;x a;}
gate gma a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glZ a,b,B,C,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glZ a,b,B,C,E,F,G,H,J,K;}
gate gmc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gma a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gma a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gma a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gme a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glZ a,b,z,A,C,D,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glZ a,b,z,A,C,D,E,F,J,K;}
gate gmg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gme a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gme a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gme a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glZ a,b,x,y,A,B,C,D,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glZ a,b,x,y,A,B,C,D,J,K;}
gate gmk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glZ a,b,v,w,y,z,A,B,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glZ a,b,v,w,y,z,A,B,J,K;}
gate gmo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
glZ a,b,t,u,w,x,y,z,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;glZ a,b,t,u,w,x,y,z,J,K;}
gate gms a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcg a,b,x,y,z,A,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcg a,b,x,y,z,A,F,G,H,I,J,K;}
gate gmw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcg a,b,v,w,x,y,D,E,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcg a,b,v,w,x,y,D,E,F,G,J,K;}
gate gmA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gcg a,b,t,u,v,w,B,C,D,E,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gcg a,b,t,u,v,w,B,C,D,E,J,K;}
gate gmE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
glx a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glB c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glE e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glI g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glM i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glQ k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glU m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;glY o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gmc o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gmg m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gmk k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gmo i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gms g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gmw e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gmA c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gmE a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gmH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gh b,e,j,l,n,o,r,s;ccx t,a,s;x b;ccx t,a,s;gm b,d,e,f,g,h,k,m,n,q,s;ccx t,a,s;x a;ccx t,a,s;gm b,c,h,i,j,k,l,o,p,q,s;ccx t,a,s;x a;}
gate gmI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gmH a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gmH a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gmK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gg b,c,d,f,g,j,l,m,p,r;ccx s,a,r;x b;ccx s,a,r;gm b,c,g,i,j,k,l,o,p,q,r;ccx s,a,r;x a;ccx s,a,r;gg b,d,e,g,h,k,m,n,q,r;ccx s,a,r;x a;}
gate gmM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gmL a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gmL a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gmO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gg b,e,f,h,i,l,n,o,r,s;ccx t,a,s;x b;ccx t,a,s;gm b,d,e,g,h,i,j,m,n,q,s;ccx t,a,s;x a;ccx t,a,s;gm b,c,g,h,j,k,l,o,p,q,s;ccx t,a,s;x a;}
gate gmQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gmP a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gmP a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gmS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gg b,c,d,f,g,h,k,l,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,g,h,j,k,n,o,p,q;ccx r,a,q;x a;ccx r,a,q;gg b,d,e,g,h,i,l,m,p,q;ccx r,a,q;x a;}
gate gmU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gmT a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gmT a,b,t,u,v,w,x,y,z,A,C,D,E,F,G,H,J,K;}
gate gmW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gmX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gg b,e,f,h,i,j,k,l,o,p;ccx q,a,p;x b;ccx q,a,p;gr b,d,e,g,h,i,k,n,p;ccx q,a,p;x a;ccx q,a,p;gr b,c,g,h,j,l,m,n,p;ccx q,a,p;x a;}
gate gmY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gmX a,b,t,u,v,w,x,y,z,A,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gmX a,b,t,u,v,w,x,y,z,A,E,F,G,H,I,J,K;}
gate gna a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gmY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gmY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gmY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnb a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gh b,c,d,f,g,h,k,m;ccx n,a,m;x b;ccx n,a,m;gh b,c,g,h,j,k,l,m;ccx n,a,m;x a;ccx n,a,m;gh b,d,e,g,h,i,l,m;ccx n,a,m;x a;}
gate gnc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnb a,b,t,u,v,w,x,y,z,A,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnb a,b,t,u,v,w,x,y,z,A,G,H,J,K;}
gate gne a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnf a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gh b,e,f,h,i,j,l,m;ccx n,a,m;x b;ccx n,a,m;gbx b,d,e,g,h,i,m;ccx n,a,m;x a;ccx n,a,m;gbx b,c,g,h,j,k,m;ccx n,a,m;x a;}
gate gng a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnf a,b,t,u,v,w,x,y,z,A,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnf a,b,t,u,v,w,x,y,z,A,H,I,J,K;}
gate gni a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gng a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gng a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gng a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gbx b,d,h,i,k,m,n;ccx o,a,n;x b;ccx o,a,n;gbx b,f,g,i,j,k,n;ccx o,a,n;x a;ccx o,a,n;gr b,c,e,f,g,j,k,l,n;ccx o,a,n;x a;}
gate gnk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnj a,b,t,u,v,w,x,y,z,A,B,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnj a,b,t,u,v,w,x,y,z,A,B,H,I,J,K;}
gate gnm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnn a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gg b,c,d,e,f,g,h,i,l,m;ccx n,a,m;x b;ccx n,a,m;gr b,c,d,e,f,g,h,k,m;ccx n,a,m;x a;ccx n,a,m;gg b,c,d,e,f,g,i,j,k,m;ccx n,a,m;x a;}
gate gno a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnn a,b,t,u,v,y,B,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnn a,b,t,u,v,y,B,E,F,G,H,I,J,K;}
gate gnq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gno a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gno a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gno a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gns a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gbd b,c,d,e,f,g,h,i,k,l,m,n;ccx o,a,n;x b;ccx o,a,n;gg b,c,d,e,f,g,h,l,m,n;ccx o,a,n;x a;ccx o,a,n;gm b,c,d,e,f,g,i,j,l,m,n;ccx o,a,n;x a;}
gate gnt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gns a,b,t,u,v,y,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gns a,b,t,u,v,y,B,C,D,E,F,G,I,J,K;}
gate gnv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gX b,c,d,e,f,g,i,j,k,l,m,n,o;ccx p,a,o;x b;ccx p,a,o;gbd b,c,d,e,f,g,h,k,l,m,n,o;ccx p,a,o;x a;ccx p,a,o;gm b,c,d,e,f,j,k,l,m,n,o;ccx p,a,o;x a;}
gate gny a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnx a,b,t,u,v,y,A,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnx a,b,t,u,v,y,A,B,C,D,E,F,G,I,J,K;}
gate gnA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gny a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gny a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gny a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gh b,c,d,e,h,o,p,q;ccx r,a,q;x b;ccx r,a,q;gX b,c,d,e,g,i,j,k,l,m,n,p,q;ccx r,a,q;x a;ccx r,a,q;gdN b,c,d,e,f,g,h,i,j,k,l,m,n,p,q;ccx r,a,q;x a;}
gate gnD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnC a,b,t,u,v,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnC a,b,t,u,v,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gnF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnH a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gbd b,c,d,e,f,g,h,i,j,k,l,m;ccx n,a,m;x b;ccx n,a,m;gg b,c,d,e,f,h,j,k,l,m;ccx n,a,m;x a;ccx n,a,m;gg b,c,d,e,g,i,j,k,l,m;ccx n,a,m;x a;}
gate gnI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnH a,b,t,u,v,w,x,y,z,A,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnH a,b,t,u,v,w,x,y,z,A,H,I,J,K;}
gate gnK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnM a,b,c,d,e,f,g,h,i,j,k,l{
x b;ccx l,a,k;gr b,c,e,f,g,h,i,j,k;ccx l,a,k;x b;ccx l,a,k;gbx b,c,f,h,i,j,k;ccx l,a,k;x a;ccx l,a,k;gh b,c,d,g,h,i,j,k;ccx l,a,k;x a;}
gate gnN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnM a,b,t,u,v,w,x,B,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnM a,b,t,u,v,w,x,B,H,I,J,K;}
gate gnP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gbx b,c,g,i,k,l,n;ccx o,a,n;x b;ccx o,a,n;gbx b,e,f,i,k,l,n;ccx o,a,n;x a;ccx o,a,n;gbx b,d,h,j,l,m,n;ccx o,a,n;x a;}
gate gnS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnR a,b,t,u,v,w,x,y,A,B,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnR a,b,t,u,v,w,x,y,A,B,G,H,I,J,K;}
gate gnU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gnW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,d,e,f,h,i,k,m,o;ccx p,a,o;x b;ccx p,a,o;gbx b,c,d,h,k,l,o;ccx p,a,o;x a;ccx p,a,o;gr b,e,f,g,i,j,l,n,o;ccx p,a,o;x a;}
gate gnX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gnW a,b,t,u,v,w,x,y,z,A,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gnW a,b,t,u,v,w,x,y,z,A,E,F,H,I,J,K;}
gate gnZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gnX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gnX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gnX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gob a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gmK a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gmO c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gmS e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gmW g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gna i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gne k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gni m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gnm o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gnq o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnv m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnA k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnF i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnK g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnP e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnU c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gnZ a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate goc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gbd b,c,d,e,f,g,h,j,l,m,n,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,e,f,g,h,m,n,p,q;ccx r,a,q;x a;ccx r,a,q;gbd b,d,e,f,g,h,i,k,m,n,o,q;ccx r,a,q;x a;}
gate god a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goc a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goc a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gof a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
god a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ god a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;god a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gog a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gbd b,d,e,f,g,h,i,k,m,n,o,q;ccx r,a,q;x b;ccx r,a,q;gbx b,c,g,h,n,p,q;ccx r,a,q;x a;ccx r,a,q;gr b,c,d,g,h,j,l,n,q;ccx r,a,q;x a;}
gate goh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gog a,b,t,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gog a,b,t,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate goj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goh a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gok a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gr b,d,g,i,j,l,n,p,r;ccx s,a,r;x b;ccx s,a,r;gX b,c,d,e,f,i,j,k,l,m,n,o,r;ccx s,a,r;x a;ccx s,a,r;gr b,e,h,j,k,m,o,q,r;ccx s,a,r;x a;}
gate gol a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gok a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gok a,b,t,u,v,w,x,y,A,B,C,D,E,F,G,H,I,J,K;}
gate gon a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gol a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gol a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gol a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,c,h,i,j,l,o,p;ccx q,a,p;x b;ccx q,a,p;gg b,c,e,g,i,j,k,l,m,p;ccx q,a,p;x a;ccx q,a,p;gg b,c,d,f,g,i,k,m,n,p;ccx q,a,p;x a;}
gate gop a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goo a,b,t,u,v,w,x,y,B,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goo a,b,t,u,v,w,x,y,B,D,E,F,G,H,I,J,K;}
gate gor a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gop a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gop a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gop a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gos a,b,c,d,e,f,g,h,i,j,k,l,m,n{
x b;ccx n,a,m;gh b,c,d,e,f,i,k,m;ccx n,a,m;x b;ccx n,a,m;gg b,c,e,f,h,i,j,k,l,m;ccx n,a,m;x a;ccx n,a,m;gh b,d,e,f,g,j,l,m;ccx n,a,m;x a;}
gate got a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gos a,b,t,u,v,w,x,y,B,C,F,G,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gos a,b,t,u,v,w,x,y,B,C,F,G,J,K;}
gate gov a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
got a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ got a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;got a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gow a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gh b,d,e,f,g,l,n,p;ccx q,a,p;x b;ccx q,a,p;gr b,c,d,e,i,j,k,m,p;ccx q,a,p;x a;ccx q,a,p;gh b,e,f,g,h,m,o,p;ccx q,a,p;x a;}
gate gox a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gow a,b,t,v,w,x,y,z,A,B,C,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gow a,b,t,v,w,x,y,z,A,B,C,D,E,H,I,J,K;}
gate goz a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gox a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gox a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gox a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gm b,c,f,i,j,k,l,m,n,q,s;ccx t,a,s;x b;ccx t,a,s;gr b,e,g,h,l,m,n,p,s;ccx t,a,s;x a;ccx t,a,s;gm b,d,g,j,k,l,m,n,o,r,s;ccx t,a,s;x a;}
gate goB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goA a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goA a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate goD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gdN b,c,e,f,g,h,i,j,k,m,n,o,p,q,s;ccx t,a,s;x b;ccx t,a,s;gr b,g,i,j,n,o,p,r,s;ccx t,a,s;x a;ccx t,a,s;gm b,c,d,g,i,j,l,n,o,p,s;ccx t,a,s;x a;}
gate goF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goE a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goE a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate goH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gh b,d,g,j,l,m,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,d,f,h,i,k,l,o,q;ccx r,a,q;x a;ccx r,a,q;gh b,e,h,k,m,n,p,q;ccx r,a,q;x a;}
gate goJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goI a,b,t,v,w,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goI a,b,t,v,w,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate goL a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gh b,c,e,g,i,j,l,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,d,e,f,g,h,i,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,d,f,h,j,k,m,o;ccx p,a,o;x a;}
gate goO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goN a,b,t,u,x,y,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goN a,b,t,u,x,y,A,B,C,D,E,F,G,H,J,K;}
gate goQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,c,d,e,g,h,i,j,l,n,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,e,h,i,j,o,q,r;ccx s,a,r;x a;ccx s,a,r;gbd b,d,e,f,h,i,j,k,m,o,p,r;ccx s,a,r;x a;}
gate goT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goS a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goS a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate goV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate goX a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gm b,c,d,e,f,l,m,n,p,q,s;ccx t,a,s;x b;ccx t,a,s;gbx b,d,e,k,n,r,s;ccx t,a,s;x a;ccx t,a,s;gbd b,c,d,e,g,h,i,j,l,n,o,s;ccx t,a,s;x a;}
gate goY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
goX a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;goX a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gpa a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
goY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ goY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;goY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gr b,c,h,i,m,n,p,q,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,e,g,i,j,l,q,r;ccx s,a,r;x a;ccx s,a,r;gbd b,c,d,f,g,j,k,l,m,o,q,r;ccx s,a,r;x a;}
gate gpd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpc a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpc a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,I,J,K;}
gate gpf a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gph a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gg b,d,h,i,k,l,n,o,q,s;ccx t,a,s;x b;ccx t,a,s;gbd b,c,d,e,f,g,h,i,j,o,q,s;ccx t,a,s;x a;ccx t,a,s;gg b,e,i,j,l,m,o,p,r,s;ccx t,a,s;x a;}
gate gpi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gph a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gph a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gpk a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpm a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,d,e,g,h,j,k,l,n,o,p,r;ccx s,a,r;x b;ccx s,a,r;gg b,c,d,e,f,j,l,o,q,r;ccx s,a,r;x a;ccx s,a,r;gg b,c,f,g,i,j,l,m,o,r;ccx s,a,r;x a;}
gate gpn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpm a,b,t,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpm a,b,t,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gpp a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpr a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gbd b,c,d,f,g,i,j,k,m,n,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,g,j,k,n,o,q,r;ccx s,a,r;x a;ccx s,a,r;gbd b,d,e,g,h,j,k,l,n,o,p,r;ccx s,a,r;x a;}
gate gps a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpr a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpr a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,J,K;}
gate gpu a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gps a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gps a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gps a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpw a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gof a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;goj c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gon e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gor g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gov i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;goz k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;goD m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;goH o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ goL o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ goQ m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ goV k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gpa i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gpf g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gpk e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gpp c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gpu a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
gate gpx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gm b,d,e,f,h,i,j,m,n,o,q;ccx r,a,q;x b;ccx r,a,q;gg b,c,d,e,g,h,l,m,p,q;ccx r,a,q;x a;ccx r,a,q;gbx b,c,f,i,k,n,q;ccx r,a,q;x a;}
gate gpy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpx a,b,t,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpx a,b,t,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gpA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpB a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gbx b,d,h,j,l,n,p;ccx q,a,p;x b;ccx q,a,p;gm b,c,d,e,f,g,h,k,l,m,p;ccx q,a,p;x a;ccx q,a,p;gbx b,e,i,k,m,o,p;ccx q,a,p;x a;}
gate gpC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpB a,b,t,u,v,w,x,y,z,B,C,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpB a,b,t,u,v,w,x,y,z,B,C,D,E,H,I,J,K;}
gate gpE a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gr b,c,h,i,k,l,o,q,s;ccx t,a,s;x b;ccx t,a,s;gm b,e,f,g,h,i,j,n,o,p,s;ccx t,a,s;x a;ccx t,a,s;gr b,d,i,j,l,m,p,r,s;ccx t,a,s;x a;}
gate gpG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpF a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpF a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gpI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpG a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpJ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gg b,c,e,f,g,h,l,m,q,r;ccx s,a,r;x b;ccx s,a,r;gh b,c,f,h,i,k,o,r;ccx s,a,r;x a;ccx s,a,r;gm b,c,d,g,i,j,k,l,n,p,r;ccx s,a,r;x a;}
gate gpK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpJ a,b,t,u,v,w,x,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpJ a,b,t,u,v,w,x,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gpM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o{
x b;ccx o,a,n;gm b,d,e,f,g,h,i,j,l,m,n;ccx o,a,n;x b;ccx o,a,n;gh b,e,f,g,h,j,m,n;ccx o,a,n;x a;ccx o,a,n;gg b,c,e,f,g,i,j,k,m,n;ccx o,a,n;x a;}
gate gpO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpN a,b,t,u,v,y,B,C,D,E,F,G,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpN a,b,t,u,v,y,B,C,D,E,F,G,I,J,K;}
gate gpQ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpO a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gg b,c,d,h,j,l,m,n,o,q;ccx r,a,q;x b;ccx r,a,q;gh b,d,i,k,l,n,p,q;ccx r,a,q;x a;ccx r,a,q;gg b,c,d,e,f,g,j,m,n,q;ccx r,a,q;x a;}
gate gpS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpR a,b,t,u,v,w,x,y,z,B,C,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpR a,b,t,u,v,w,x,y,z,B,C,E,F,G,H,I,J,K;}
gate gpU a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpS a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpV a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q{
x b;ccx q,a,p;gg b,d,e,f,g,h,l,n,o,p;ccx q,a,p;x b;ccx q,a,p;gg b,c,d,g,j,k,m,n,o,p;ccx q,a,p;x a;ccx q,a,p;gh b,c,e,g,i,k,l,p;ccx q,a,p;x a;}
gate gpW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpV a,b,t,u,v,w,x,y,z,A,B,C,D,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpV a,b,t,u,v,w,x,y,z,A,B,C,D,G,H,J,K;}
gate gpY a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gpW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gpW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gpW a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gpZ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gh b,c,e,g,i,k,l,o;ccx p,a,o;x b;ccx p,a,o;gbd b,c,d,e,f,g,h,i,j,k,n,o;ccx p,a,o;x a;ccx p,a,o;gh b,d,f,h,j,l,m,o;ccx p,a,o;x a;}
gate gqa a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gpZ a,b,u,v,w,x,y,z,A,B,C,D,E,F,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gpZ a,b,u,v,w,x,y,z,A,B,C,D,E,F,J,K;}
gate gqc a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqa a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqa a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqa a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqd a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r{
x b;ccx r,a,q;gg b,c,e,f,g,h,k,l,p,q;ccx r,a,q;x b;ccx r,a,q;gbx b,c,f,h,i,n,q;ccx r,a,q;x a;ccx r,a,q;gg b,c,d,g,i,j,k,m,o,q;ccx r,a,q;x a;}
gate gqe a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqd a,b,t,u,v,w,x,z,A,B,C,D,E,F,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqd a,b,t,u,v,w,x,z,A,B,C,D,E,F,H,I,J,K;}
gate gqg a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqe a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqe a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqe a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqi a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gr b,c,h,i,j,k,n,p,r;ccx s,a,r;x b;ccx s,a,r;gg b,e,f,g,h,i,m,n,o,r;ccx s,a,r;x a;ccx s,a,r;gr b,d,i,j,k,l,o,q,r;ccx s,a,r;x a;}
gate gqj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqi a,b,t,u,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqi a,b,t,u,v,w,x,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gql a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqj a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqn a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gbx b,d,h,i,k,m,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,d,e,f,g,j,k,l,o;ccx p,a,o;x a;ccx p,a,o;gbx b,e,i,j,l,n,o;ccx p,a,o;x a;}
gate gqo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqn a,b,t,u,v,w,x,z,A,B,D,E,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqn a,b,t,u,v,w,x,z,A,B,D,E,H,I,J,K;}
gate gqq a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqo a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqs a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,d,f,g,h,k,l,m,o;ccx p,a,o;x b;ccx p,a,o;gh b,c,d,e,j,k,n,o;ccx p,a,o;x a;ccx p,a,o;gbx b,c,e,f,i,l,o;ccx p,a,o;x a;}
gate gqt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqs a,b,t,v,y,z,A,B,C,D,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqs a,b,t,v,y,z,A,B,C,D,F,G,H,I,J,K;}
gate gqv a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqt a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqx a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p{
x b;ccx p,a,o;gr b,c,e,f,g,j,k,l,o;ccx p,a,o;x b;ccx p,a,o;gg b,c,d,e,g,i,j,l,n,o;ccx p,a,o;x a;ccx p,a,o;gr b,d,f,g,h,k,l,m,o;ccx p,a,o;x a;}
gate gqy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqx a,b,t,u,x,y,z,A,B,D,E,F,G,H,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqx a,b,t,u,x,y,z,A,B,D,E,F,G,H,J,K;}
gate gqA a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqy a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqC a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,d,g,h,j,k,l,n,o,r;ccx s,a,r;x b;ccx s,a,r;gr b,c,f,g,k,l,o,q,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,e,h,i,k,l,m,o,p,r;ccx s,a,r;x a;}
gate gqD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqC a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqC a,b,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gqF a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqD a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqH a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t{
x b;ccx t,a,s;gbd b,c,e,f,h,i,l,m,n,p,q,s;ccx t,a,s;x b;ccx t,a,s;gbj b,h,l,n,r,s;ccx t,a,s;x a;ccx t,a,s;gm b,c,d,g,h,j,k,l,n,o,s;ccx t,a,s;x a;}
gate gqI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqH a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqH a,b,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gqK a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqI a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqM a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s{
x b;ccx s,a,r;gm b,c,e,g,h,i,j,k,m,p,r;ccx s,a,r;x b;ccx s,a,r;gbj b,f,i,k,o,r;ccx s,a,r;x a;ccx s,a,r;gm b,d,f,h,i,j,k,l,n,q,r;ccx s,a,r;x a;}
gate gqN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K{
gqM a,b,t,u,v,w,y,z,A,B,C,D,E,F,G,H,I,J,K;ga c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J;gqM a,b,t,u,v,w,y,z,A,B,C,D,E,F,G,H,I,J,K;}
gate gqP a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L{
gqN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;gf c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K;inv @ gqN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;x s;cx s,K;x s;gqN a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,L;}
gate gqR a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z{
gpA a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gpE c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gpI e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gpM g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gpQ i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gpU k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gpY m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;gqc o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;cx q,a;ccx Z,a,q;cx q,a;cx r,b;ccx Z,b,r;cx r,b;cx s,c;ccx Z,c,s;cx s,c;cx t,d;ccx Z,d,t;cx t,d;cx u,e;ccx Z,e,u;cx u,e;cx v,f;ccx Z,f,v;cx v,f;cx w,g;ccx Z,g,w;cx w,g;cx x,h;ccx Z,h,x;cx x,h;cx y,i;ccx Z,i,y;cx y,i;cx z,j;ccx Z,j,z;cx z,j;cx A,k;ccx Z,k,A;cx A,k;cx B,l;ccx Z,l,B;cx B,l;cx C,m;ccx Z,m,C;cx C,m;cx D,n;ccx Z,n,D;cx D,n;cx E,o;ccx Z,o,E;cx E,o;cx F,p;ccx Z,p,F;cx F,p;inv @ gqg o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gql m,n,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gqq k,l,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gqv i,j,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gqA g,h,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gqF e,f,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gqK c,d,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;inv @ gqP a,b,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;}
qreg q[52];
creg j0[1];
creg j1[1];
creg j2[1];
creg j3[1];
creg j4[1];
creg j5[1];
creg j6[1];
creg j7[1];
creg j8[1];
creg j9[1];
creg j10[1];
creg k0[1];
creg k1[1];
creg k2[1];
creg k3[1];
x q[0];
h q[51];
gbI q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
h q[51];
measure q[51] -> j0[0];
if(j0==1) x q[51];
h q[51];
gdb q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j1[0];
if(j1==1) x q[51];
h q[51];
gez q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.78539816339744828) q[51];
if(j1==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j2[0];
if(j2==1) x q[51];
h q[51];
gfT q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.39269908169872414) q[51];
if(j1==1) p(0.78539816339744828) q[51];
if(j2==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j3[0];
if(j3==1) x q[51];
h q[51];
ghm q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.19634954084936207) q[51];
if(j1==1) p(0.39269908169872414) q[51];
if(j2==1) p(0.78539816339744828) q[51];
if(j3==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j4[0];
if(j4==1) x q[51];
h q[51];
giC q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.098174770424681035) q[51];
if(j1==1) p(0.19634954084936207) q[51];
if(j2==1) p(0.39269908169872414) q[51];
if(j3==1) p(0.78539816339744828) q[51];
if(j4==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j5[0];
if(j5==1) x q[51];
h q[51];
gjW q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.049087385212340517) q[51];
if(j1==1) p(0.098174770424681035) q[51];
if(j2==1) p(0.19634954084936207) q[51];
if(j3==1) p(0.39269908169872414) q[51];
if(j4==1) p(0.78539816339744828) q[51];
if(j5==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j6[0];
if(j6==1) x q[51];
h q[51];
gkC q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.024543692606170259) q[51];
if(j1==1) p(0.049087385212340517) q[51];
if(j2==1) p(0.098174770424681035) q[51];
if(j3==1) p(0.19634954084936207) q[51];
if(j4==1) p(0.39269908169872414) q[51];
if(j5==1) p(0.78539816339744828) q[51];
if(j6==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j7[0];
if(j7==1) x q[51];
h q[51];
gkF q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.012271846303085129) q[51];
if(j1==1) p(0.024543692606170259) q[51];
if(j2==1) p(0.049087385212340517) q[51];
if(j3==1) p(0.098174770424681035) q[51];
if(j4==1) p(0.19634954084936207) q[51];
if(j5==1) p(0.39269908169872414) q[51];
if(j6==1) p(0.78539816339744828) q[51];
if(j7==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j8[0];
if(j8==1) x q[51];
h q[51];
gkH q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.0061359231515425647) q[51];
if(j1==1) p(0.012271846303085129) q[51];
if(j2==1) p(0.024543692606170259) q[51];
if(j3==1) p(0.049087385212340517) q[51];
if(j4==1) p(0.098174770424681035) q[51];
if(j5==1) p(0.19634954084936207) q[51];
if(j6==1) p(0.39269908169872414) q[51];
if(j7==1) p(0.78539816339744828) q[51];
if(j8==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j9[0];
if(j9==1) x q[51];
h q[51];
glt q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(j0==1) p(0.0030679615757712823) q[51];
if(j1==1) p(0.0061359231515425647) q[51];
if(j2==1) p(0.012271846303085129) q[51];
if(j3==1) p(0.024543692606170259) q[51];
if(j4==1) p(0.049087385212340517) q[51];
if(j5==1) p(0.098174770424681035) q[51];
if(j6==1) p(0.19634954084936207) q[51];
if(j7==1) p(0.39269908169872414) q[51];
if(j8==1) p(0.78539816339744828) q[51];
if(j9==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> j10[0];
if(j10==1) x q[51];
h q[51];
gmG q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
h q[51];
measure q[51] -> k0[0];
if(k0==1) x q[51];
h q[51];
gob q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(k0==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> k1[0];
if(k1==1) x q[51];
h q[51];
gpw q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(k0==1) p(0.78539816339744828) q[51];
if(k1==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> k2[0];
if(k2==1) x q[51];
h q[51];
gqR q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],q[8],q[9],q[10],q[11],q[12],q[13],q[14],q[15],q[16],q[17],q[18],q[19],q[20],q[21],q[22],q[23],q[24],q[25],q[26],q[27],q[28],q[29],q[30],q[31],q[32],q[33],q[34],q[35],q[36],q[37],q[38],q[39],q[40],q[41],q[42],q[43],q[44],q[45],q[46],q[47],q[48],q[49],q[50],q[51];
if(k0==1) p(0.39269908169872414) q[51];
if(k1==1) p(0.78539816339744828) q[51];
if(k2==1) p(1.5707963267948966) q[51];
h q[51];
measure q[51] -> k3[0];
if(k3==1) x q[51];
